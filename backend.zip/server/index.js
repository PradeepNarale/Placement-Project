const express = require('express');
const mongoose = require('mongoose');
const app = express();
const cors = require('cors')
app.use(express.json());
const router = require('./routes/inserProduct')

const URL = 'mongodb://localhost:27017/form';
app.listen(3005, () => {
    console.log("Server is running on port 3005");
})
app.use(cors());
app.use(router)
const moongose = mongoose.connect(URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
if (moongose) {
    console.log("MongoDB Connected");
}
else {
    console.log("MongoDB Not Connected");
}