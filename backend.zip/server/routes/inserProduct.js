const express = require('express');
const router = express.Router();
const Product = require('../Schemas/productScehma')

router.post('/addproduct', async (req, res) => {
    const { title, subtitle, description } = req.body;
    try {
        if (!title || !subtitle || !description) {
            res.status(500).send({ msg: "ALL FIELDS ARE MEDTORY" })
        }
        else {
            const newProduct = await new Product({ title, subtitle, description })
            await newProduct.save();
            res.status(201).send({ msg: "Product Upload Sucessfully" })
        }
    } catch (error) {
        res.status(500).json({ msg: "An error occurred while saving the product" });
    }
})

router.get('/getProduct', async (req, res) => {
    try {
        const products = await Product.find();
        if (products.length > 0) {
            res.status(200).send(products);
        } else {
            res.status(404).send("Products list is empty");
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "An error occurred while getting the product" });
    }
});

router.delete('/deleteProduct/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        console.log(productId)
        const deletedProduct = await Product.findByIdAndRemove(productId);
        if (deletedProduct) {
            res.status(200).json({ msg: "Product deleted successfully", product: deletedProduct });
        } else {
            res.status(404).json({ msg: "Product not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "An error occurred while deleting the product" });
    }
});

router.get('/getProduct/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        const product = await Product.findById(productId);
        if (!product) {
            res.status(404).json({ msg: "Product not found" });
            return;
        }
        res.status(200).json(product);
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "An error occurred while retrieving product details" });
    }
});

router.post('/updateProduct/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        const { title, subtitle, description } = req.body;
        const updatedProduct = await Product.findById(productId); // Find the product by ID
        if (!updatedProduct) {
            return res.status(404).json({ msg: "Product not found" });
        }
        updatedProduct.title = title;
        updatedProduct.subtitle = subtitle;
        updatedProduct.description = description;
        await updatedProduct.save(); 
        res.status(200).json({ msg: "Product updated successfully", product: updatedProduct });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: "An error occurred while updating the product" });
    }
});




module.exports = router;