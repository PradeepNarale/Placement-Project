const moongose = require('mongoose');

const product = moongose.Schema({
    title: {
        type: String,
        required: true
    },
    subtitle: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
})

const Product = moongose.model('Product', product)
module.exports=  Product;